

 let plan = document.querySelector('#plans');
 let options = document.querySelectorAll('#navelements');

 options.forEach(function(option){
     option.addEventListener('click',function(opt){
      
        if(opt.target.id==='homep'){
            document.location.href = " http://127.0.0.1:5500/.vscode/Hot-Spot/plans.html";
        }
        else if(opt.target.id==='aboutinfo'){
            document.location.href = "";
        }
        else if(opt.target.id=='contactUs'){
          document.location.href = " ";
        }
    })
 })

 plan.addEventListener('click',function(e){
    
    if(e.target.id === 'plans'){
        document.location.href = "http://127.0.0.1:5500/.vscode/Hot-Spot/plans.html";
    }



 })